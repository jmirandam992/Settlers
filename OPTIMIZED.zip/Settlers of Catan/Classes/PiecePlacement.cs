﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOCForm.Classes
{
    public class PiecePlacement
    {
        public PiecePlacement(int HexSize)
        {
            this.hexSize = HexSize;
        }

        private int hexSize;
        private int townSize = 30;

        public void Towns(Form1 form, Hexagon[] Grid, int loc, int hexRef)
        {
            if (loc == 0)
            {
                HouseGen(form, Grid, loc, hexRef, ((hexSize / 2) - 15), -15);
            }
            if (loc == 1)
            {
                HouseGen(form, Grid, loc, hexRef, (hexSize - 15), (hexSize / 4) - 15);
            }
            if (loc == 2)
            {
                HouseGen(form, Grid, loc, hexRef, (hexSize - 15), (hexSize / 4) + (hexSize / 2) - 15);
            }
            if (loc == 3)
            {
                HouseGen(form, Grid, loc, hexRef, ((hexSize / 2) - 15), (hexSize - 15));
            }
            if (loc == 4)
            {
                HouseGen(form, Grid, loc, hexRef, -15, (hexSize / 4) + (hexSize / 2) - 15);
            }
            if (loc == 5)
            {
                HouseGen(form, Grid, loc, hexRef, -15, (hexSize / 4) - 15);
            }

            
        }

        private void HouseGen(Form1 form, Hexagon[] Grid, int loc, int hexRef, int x, int y)
        {
            PictureBox house = new PictureBox()
            {
                Name = "pictureBox",
                Size = new Size(townSize, townSize),
                Location = new Point(Grid[hexRef].LocX + x, Grid[hexRef].LocY + y),
                Image = Image.FromFile("Media\\house.jpg"),
                BackColor = Color.Transparent,
            };
            form.Controls.Add(house);
        }
    }
}
