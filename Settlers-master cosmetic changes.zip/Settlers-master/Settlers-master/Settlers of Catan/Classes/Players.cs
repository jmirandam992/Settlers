﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOCForm.Classes
{
    public class Players
    {
        public Players(int Players, int AI)
        {


        }

        private bool diceRolled;

        private int victoryPoints;

        private int cityCount;

        private int townCount;

        private int maxRoadLength;

        //private int










    }
}
