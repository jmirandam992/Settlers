﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOCForm.Classes
{
    class Trading
    {

        private string trader;
        private string tradee;


        private void iniateTrade()
        {

        }

        private void counterTrade()
        {

        }

        private void acceptTrade()
        {

        }

        private void declineTrade()
        {

        }


    }
}
