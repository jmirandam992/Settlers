﻿namespace diceRoll_Improved
{
    partial class frmDiceRoller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlDie1 = new System.Windows.Forms.Panel();
            this.pnlDie2 = new System.Windows.Forms.Panel();
            this.tmrDieRoll = new System.Windows.Forms.Timer(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // pnlDie1
            // 
            this.pnlDie1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlDie1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlDie1.Location = new System.Drawing.Point(70, 82);
            this.pnlDie1.Name = "pnlDie1";
            this.pnlDie1.Size = new System.Drawing.Size(80, 80);
            this.pnlDie1.TabIndex = 0;
            this.pnlDie1.Click += new System.EventHandler(this.PnlDie1_Click);
            // 
            // pnlDie2
            // 
            this.pnlDie2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlDie2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlDie2.Location = new System.Drawing.Point(238, 82);
            this.pnlDie2.Name = "pnlDie2";
            this.pnlDie2.Size = new System.Drawing.Size(80, 80);
            this.pnlDie2.TabIndex = 1;
            this.pnlDie2.Click += new System.EventHandler(this.PnlDie2_Click);
            // 
            // tmrDieRoll
            // 
            this.tmrDieRoll.Tick += new System.EventHandler(this.TmrDieRoll_Tick);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(70, 191);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(248, 26);
            this.progressBar1.TabIndex = 2;
            // 
            // frmDiceRoller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 245);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.pnlDie2);
            this.Controls.Add(this.pnlDie1);
            this.Name = "frmDiceRoller";
            this.Text = "Dice Roller";
            this.Load += new System.EventHandler(this.FrmDiceRoller_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDie1;
        private System.Windows.Forms.Panel pnlDie2;
        private System.Windows.Forms.Timer tmrDieRoll;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}

